package com.example.ebookonlinebookstore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TrendingBooks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trending_books);
    }
}